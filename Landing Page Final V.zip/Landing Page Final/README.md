# Dynamic Landing Page 

# Languagae Usage
JVS
CSS
HTML

# Functionality
1. Scrolling effect
2. Navigation

# Development
1. Open chrome browser
2.Go to index.html
3.
